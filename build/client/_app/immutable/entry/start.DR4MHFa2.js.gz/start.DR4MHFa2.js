import{d as a}from"../chunks/entry.BndfiRUm.js";export{a as start};
