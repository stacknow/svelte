import{D as o}from"./runtime.BZuW5zuQ.js";const s=o;export{s as d};
